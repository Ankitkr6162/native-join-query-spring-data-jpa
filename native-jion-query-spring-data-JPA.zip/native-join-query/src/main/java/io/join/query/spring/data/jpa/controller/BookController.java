package io.join.query.spring.data.jpa.controller;

import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import io.join.query.spring.data.jpa.entity.Book;
import io.join.query.spring.data.jpa.service.BookService;

@RestController
@RequestMapping("/book")
public class BookController {

	private final BookService bookService;

	
	public BookController(BookService bookService) {
		this.bookService = bookService;
	}

	@GetMapping("/by-author")
	public ResponseEntity<List<Book>> getBookByAuthor(@RequestParam("authorName") String authorName) {
		List<Book> books = bookService.findBookByAuthorName(authorName);
		if (books.isEmpty()) {
			return ResponseEntity.noContent().build();
		} else {
			return ResponseEntity.ok(books);
		}

	}

}
