package io.join.query.spring.data.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import io.join.query.spring.data.jpa.entity.Book;

public interface BookRepository extends JpaRepository<Book, Long> {

	@Query(value ="SELECT b.* FROM Book b INNER JOIN Author a ON b.author_id = a.id WHERE a.name = :authorName" , nativeQuery = true)
	List<Book> findBookByAuthorName(@Param("authorName") String authorName);
}
