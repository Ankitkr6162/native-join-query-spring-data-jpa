package io.join.query.spring.data.jpa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import io.join.query.spring.data.jpa.entity.Book;
import io.join.query.spring.data.jpa.repository.BookRepository;

@Service
public class BookService {

	private final BookRepository bookRepository;

	@Autowired
	public BookService(BookRepository bookRepository) {
		this.bookRepository = bookRepository;
	}
	
	public List<Book> findBookByAuthorName(String authorName){
		return bookRepository.findBookByAuthorName(authorName);
	}
}
