package io.join.query.spring.data.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NativeJoinQueryApplication {

	public static void main(String[] args) {
		SpringApplication.run(NativeJoinQueryApplication.class, args);
	}

}
